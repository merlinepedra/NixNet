---
layout: page
title: Fuck Google
subtitle: Invidious is no more
description: Google blocked my IP address so Invidious is down for the time being.
cover: /assets/pages/fuck-google.png
---
Google has blocked the IP address of my server because of Invidious. I don't have the money to buy another one dedicated to it so, for the time being, I won't be able to host it. When I do eventually have the funds, I'll set up an Ansible playbook that will let me migrate the instance from server to server as the IPs are blocked. I don't know when that will be but it will happen eventually.
