---
layout: post
title: Community Hangout
subtitle: Simple get together on Mumble for whoever wants to join
description: Just a notification via RSS about a get together on April 24th with a poll linked to decide on times
cover: /assets/pages/group.png
date: 2020-04-12 20:41 -0400
---
I've already posted about it on [on Mastodon](https://social.nixnet.services/@amolith/103988472212077632) but I thought I would do so here as well in case anyone subscribes to the feed who isn't on the Fediverse.

I will be hosting a community hangout on Mumble at some point on April 24th—coincidentally the same day I'll be deleting the old Mastodon server—and I'll be around for an hour or so to talk about whatever; there is no specific topic. If you want to join in, please vote in [the poll](https://poll.nixnet.services/UDBjYW4UxtW42YEIxNPTXjsT/admin) so I can see what time range works for the most people!

On a side note, I will be moving blog posts from here to my [personal site](https://secluded.site) in the next few days. The Blog menu item above will lead there as well.
