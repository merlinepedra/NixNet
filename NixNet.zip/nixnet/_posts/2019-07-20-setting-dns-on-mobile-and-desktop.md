---
layout: post
title: Setting DoT on mobile and desktop
subtitle: Enhancing your personal privacy by setting custom DoT servers on all your devices
description: Enhancing your personal privacy by setting custom DoT servers on all your devices
tags: privacy mobile desktop
cover: /assets/pages/dns.png
date: 2019-07-20 19:09 -0400
---
Changing your default DNS servers to ones that use DNS-over-TLS can do a lot to make your systems more secure and private. DNS is also a serious tool for censorship and tracking if used foolishly. Before choosing a provider, make ***sure*** you actually read their privacy policy and terms of service. There are some good recommendations [here](https://wiki.lelux.fi/dns/resolvers/) (I'm partial to UncensoredDNS) and of course I have to shill [my own](/dns/). Once you've chosen a provider, you'll need to get set up.

# Basic Information
For the *very* basics, I recommend reading sections 1 - 2 of a [previous post](/blog/dns-and-root-certificates-what-you-need-to-know/#1-what-is-dns-and-why-does-it-concern-you). It has good information and sets you up for this article.

Another useful term to know is [Anycast](https://en.wikipedia.org/wiki/Anycast). A lot of servers (including mine) have it set up so you only have to set and remember one IP address or hostname and you automatically use the server geographically nearest to you, the one with the lowest latency.

DoT stands for [DNS-over-TLS](https://en.wikipedia.org/wiki/DNS_over_TLS). It's a protocol that wraps DNS queries and responses in the [TLS](https://en.wikipedia.org/wiki/Transport_Layer_Security) protocol. By default, most systems use plaintext DNS and this is very insecure. Plaintext is . . . plaintext; anyone can snoop on your connection and see what websites you're visiting. If you're using DNS-over-TLS, the only parties that know where you're going is you and the DNS server itself. This article focuses on that because it's more secure and private. DNS-over-HTTPS ([DoH](https://en.wikipedia.org/wiki/DNS_over_HTTPS)) is another option but far fewer clients support it, it's more difficult to set up, and there are far fewer DoH providers.

# Setup
Linux and Android are all fairly simple to set up but I couldn't find anything for Windows other than DNS-over-HTTPS (DoH). I couldn't find anything at all for iOS but there are instructions for macOS.

## Linux
[Unbound](https://wiki.archlinux.org/index.php/Unbound) is what I use for DNS on all of my systems. It's wonderfully easy to use and works very well. Once you've used it for a while and have built up a cache, it's much faster than third-party resolvers.

*(stolen from [here](https://wiki.lelux.fi/dns-over-tls/unbound/linux/))*

Filename: `/etc/unbound/unbound.conf`


### Debian

```
server:
  tls-cert-bundle: /etc/ssl/certs/ca-certificates.crt

forward-zone:
  name: "."
  forward-tls-upstream: yes

  forward-addr: 198.251.90.114@853#uncensored.any.nixnet.xyz
  forward-addr: 51.158.147.50@853#resolver-eu.lelux.fi
  forward-addr: 91.239.100.100@853#anycast.censurfridns.dk
  forward-addr: 185.95.218.42@853#dns.digitale-gesellschaft.ch
```

### Arch

```
server:
  use-syslog: yes
  do-daemonize: no
  username: "unbound"
  directory: "/etc/unbound"
  # TODO: fix  local DNSSEC check
  # trust-anchor-file: trusted-key.key
  tls-cert-bundle: /etc/ssl/certs/ca-certificates.crt

forward-zone:
  name: "."
  forward-tls-upstream: yes

  forward-addr: 198.251.90.114@853#uncensored.any.nixnet.xyz
  forward-addr: 51.158.147.50@853#resolver-eu.lelux.fi
  forward-addr: 91.239.100.100@853#anycast.censurfridns.dk
  forward-addr: 185.95.218.42@853#dns.digitale-gesellschaft.ch
```

### Using Unbound as a local resolver
```bash
echo "nameserver 127.0.0.1" | sudo tee /etc/resolv.conf && sudo chattr +i /etc/resolv.conf
```
This sets `127.0.0.1` as your nameserver and locks the file  by adding the *immutable* flag (`chattr +i`). To remove the flag and make it editable again, run `chattr -i /etc/resolv.conf`.

## Windows
I know the title is for DNS-over-TLS but, from what I've found, DoT on Windows is **incredibly** difficult and I can't find much on it. This tell you how to change your plaintext DNS configuration so you can at least use a private resolver.
1. Open the **Control Panel**
2. Click **Network and Internet**
3. Click **Network and Sharing Center**
4. Click **Change adapter settings** in the left pane
5. Right-click the network interface connected to the internet, and select the **Properties** option
6. Select and check the **Internet Protocol Version 4 (TCP/IPv4)** option
7. Click the **Properties** button
8. Click **Use the following DNS server addresses**
9. Enter your primary and secondary DNS addresses. If you're using mine, the primary would be `198.251.90.114` and secondary would be from some other provider (such as [UncensoredDNS's](https://blog.uncensoreddns.org/dns-servers/) `91.239.100.100`)
10. Click **OK**
11. As with all things Windows, **reboot** to finish applying the changes.

**EDIT:** It was pointed out that you can use DoH on Windows using something like [Simple DNSCrypt](https://simplednscrypt.org/). After installing and getting it set up, it looks like you would just go to the **Resolvers** tab, disable **Automatic Mode**, then add whatever custom resolvers you want. I don't offer DoH *yet* but there are some providers listed on a friend's [wiki](https://wiki.lelux.fi/dns/resolvers/).

## macOS
I got this tutorial from [phiffer.org](https://phiffer.org/writing/dns-over-tls-on-macos/). I don't have anything from Apple so I can't test it but a friend of mine did and said it works.

1. Use [Homebrew](https://brew.sh/) to install `knot-resolver` then set up a service so it runs on startup with `sudo brew services start knot-resolver`
2. Use your favourite text editor to modify `/usr/local/etc/kresd/config` and add this to the very end of the file: `{% raw %}policy.add(policy.all(policy.TLS_FORWARD({{'198.251.90.114', hostname='uncensored.any.dns.nixnet.xyz'}}))){% endraw %}`
3. Restart `kresd` with `sudo brew services restart knot-resolver`
4. At this point, you should check what DNS server you're currently using to make sure it actually changes. You can do that with `kdig nixnet.xyz`
5. Go to **Apple Menu** > **System Preferences** > **Advanced** > **DNS** then add `127.0.0.1`
6. Test again with `kdig nixnet.xyz`. This time, one of the last couple IP addresses you see should show up something like `127.0.0.1@53(UDP)`.

That's it!

## Android
Note that DoT is only available on Android Pie and up. For other versions, try [Nebulo](https://smokescreen.app). I go over the process of installing and using it in my last [post](/blog/blocking-ads-on-mobile-and-desktop/#non-rooted-phones). Once you've gone through that, you're pretty much good to. If you want to add additional servers tap the <i class="fa fa-server"></i> server icon, then the plus at the bottom, and add whatever IP addresses or hostnames you'd like. Mine is included by default as **NixNet Uncensored** so all you have to do is select it.

# iOS
The only client I've been able to find is [DNSCloak](https://apps.apple.com/us/app/dnscloak-secure-dns-client/id1452162351). I don't use iOS so I can't attest to how well it does or doesn't work.
