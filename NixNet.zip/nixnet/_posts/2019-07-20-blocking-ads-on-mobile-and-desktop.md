---
layout: post
title: Blocking ads on mobile and desktop
subtitle: Locally getting rid of ads on most&trade; platforms
description: A semi-quick and easy guide on getting rid of ads on most&trade; platforms (browsers, Android, & iOS)
tags: privacy mobile desktop
cover: /assets/posts/adblock.png
date: 2019-07-20 19:09 -0400
---
# Forward
The more I interact with people who don't care about ads, the more I feel like I need to do something about it. To be quite honest, ads annoy the hell out of me and I can't stand them when I'm listening to audio (podcasts are an exception as long as they aren't **too** intrusive), browsing the web, or watching videos. It's a major inconvenience on both mobile and desktop so this article is aimed at the "normal" user and will cover how to block ads on (*hopefully*) all major platforms. I don't use iOS so I can't test the methods listed nor do I plan to do too much research into it.

For quick navigation, if you're simply looking for uBlock Origin configuration tips, just jump to the [heading](#ublock-origin-configuration)

# Desktop
The biggest one here is in your browser. In my *personal* opinion, any derivative of Chromium or Chrome isn't *really* worth talking about when it comes to ads because they're an advertising company before anything else and that's one of their main goals. I recommend [Firefox](https://www.mozilla.org/firefox/). It's fast, it's private, it's open source, and Mozilla isn't a company whose sole purpose is serving personalised ads. That said, I still recognise the fact that Chrome dominates the browser market. As such, I'll address it as well.

## Firefox
For general browsing, I recommend [uBlock Origin](https://addons.mozilla.org/en-US/firefox/addon/ublock-origin/). It's fast and lightweight yet very powerful and comprehensive. If you want to go a step further and have the ability to really *curate* your web experience, I recommend using [uMatrix](https://addons.mozilla.org/en-US/firefox/addon/umatrix/) *in addition to* uBlock Origin. It's harder to get used to the workflow and it takes quite a bit of time to develop a good setup but, once you do, it's phenomenal. Check the bottom section for my [configuration](#ublock-origin-configuration) recommendations!

## Chrome
Same as with Firefox, I recommend [uBlock Origin](https://chrome.google.com/webstore/detail/ublock-origin/cjpalhdlnbpafiamejdnhcphjbkeiagm) and [uMatrix](https://chrome.google.com/webstore/detail/umatrix/ogfcmafjalglgifnmanfmnieipoejdcf) together. Check the bottom for my [configuration](#ublock-origin-configuration) recommendations!

## Safari
Again, I recommend Firefox. If you're stuck on Safari, however, [uBlock Origin](https://safari-extensions.apple.com/details/?id=com.el1t.uBlock-3NU33NW2M3) is available as a desktop extension there as well. There's some general information about who develops it on the main [GitHub repo](https://github.com/gorhill/uBlock#safari-macos). For instructions on installing it, read the related [wiki page](https://github.com/el1t/uBlock-Safari/wiki/Installation-and-Updates). If you do use it over Better (below), check the last section for my uBO [configuration](#ublock-origin-configuration) recommendations.

You can also use [Better](https://better.fyi/) from [Aral Balkan](https://mastodon.ar.al/@aral). This is probably the . . . *Better* 😏 choice as Safari is known to disable uBlock Origin because it's "too heavy". I don't use macOS or iOS so I don't have any personal experience. I got some suggestions from other people, went through them, and chose two of the better ones.

# Mobile
Phones are typically more limited than desktops so blocking ads here is a bit more difficult. In the past, the Firefox Android app had support for extensions but, starting with version 70, that will be no more. Other than that, the only decent way is to use VPN or DNS techniques. I prefer Android but I know iOS is also popular so I tried to find some solutions for it as well.

## Android
### Rooted phones
If you have a rooted phone, [AdAway](https://adaway.org/) is 100% the way to go. It blocks ads not just in your browser but in every app as well. You can also define custom blocklists like the one I have at [/hosts.txt](/hosts.txt). Tap the <i class="fa fa-bars"></i> menu in the top right then `Hosts sources`. In the box, type `nixnet.services/hosts.txt`. Go back to the homescreen, enable/refresh, reboot, then enjoy ad-free Android!

### Non-rooted phones
If you **don't** have a rooted phone, try [Nebulo](https://smokescreen.app/). If you use F-Droid (which I also highly recommend), the repo is at `fdroid.frostnerd.com`. The source code for the app can be found on their [GitLab](https://git.frostnerd.com/PublicAndroidApps/smokescreen) instance as well. Nebulo is an app that lets you use DNS-over-TLS and DNS-over-HTTPS on Android. To actually block ads with it, there are a few steps you have to go through first. If you use F-Droid (recommended), follow that guide. If you stick to Google Play, follow that guide.

#### Google Play
Google doesn't like apps that block ads (being an advertising company and all). As such, the Play Store version doesn't have blocklists included by default; you'll have to add them manually. I have my own hosts file at [/hosts.txt](/hosts.txt) that anyone can use. All you have to do is open the app, open the <i class="fa fa-bars"></i> menu in the top right, tap the <i class="fa fa-plus"></i> icon. For the name, type something like NixNet lists; it really doesn't matter what you use so long as you recognise it. In the URL entry field, type `https://nixnet.services/hosts.txt`. Tap the add button, then the <i class="fa fa-refresh"></i> icon, go back to the homescreen, tap the <i class="fa fa-server"></i> icon, and pick which server you want to use (I recommend [mine](/dns/) or [UncensoredDNS](https://blog.uncensoreddns.org/)). Finally, tap start! You shouldn't see ads in any apps now!

#### F-Droid
In F-Droid, go to Settings > My Apps > Repositories then click the `+` button. Paste the URL below into the box then  tap `ADD`. Wait for your repos to update then search for `Nebulo`, install, then follow the instructions for [Google Play](#google-play)!

`https://fdroid.frostnerd.com/fdroid/repo?fingerprint=74BB580F263EC89E15C207298DEC861B5069517550FE0F1D852F16FA611D2D26`

## iOS
As I mentioned above, [Better](https://better.fyi) is what I would use if I was on iOS or macOS. I've heard good things about it from people and I think Aral is a trustworthy guy.

A close friend of mine is currently testing [AdGuard](https://apps.apple.com/app/apple-store/id1047223162), a free adblocker. I'll update this once she reaches a verdict.

# uBlock Origin Configuration
In my opinion, uBO is one of the most powerful adblocking tools there is. It has sane defaults for the new user, the settings are easy to understand nad navigate through, and there are many advanced features for people who know what they're doing. **Protip:** if there's an add on a page that you don't want to see, click the extension icon, then the <i class="fa fa-eyedropper"></i> icon, then find the element you want removed, click it, then click `Create`. That will hide the element in the future 👍

Personally, I recommend enabling the majority of the filter lists. I have all the Built-in lists enabled, Ads, Privacy, Malware domains, Annoyances, and Multipurpose. I've also added my own [hosts file](/hosts.txt) (generated with [`hblock`](https://github.com/hectorm/hblock)) in the custom section. Other than enabling additional lists, my setup is the same as default!

I also recommend taking a look at a friend of mine's [uBO Recommendations](https://theel0ja.info/ubo-recommendations/).
