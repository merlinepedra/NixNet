---
layout: post
title: Buying a domain name
subtitle: The most essential part of any new website
description: Some information about how domains work, choosing a registrar, and some considerations to keep in mind
tags: sysadmin hosting self self2019
date: 2019-10-15 13:57 -0400
cover: /assets/posts/domains.png
---

After the release of the videos from SouthEast LinuxFest 2019, I found that mine was cut off at the beginning. Because of that, I decided to do a series of posts essentially recapping the talk but including some additional information. If you haven't seen it, you can watch *Building your own cloud* on [YouTube](https://youtube.com/watch?v=SmYFBuNlukU), [Invidious](https://invidio.us/watch?v=SmYFBuNlukU), or [PeerTube](https://vid.lelux.fi/videos/watch/a43f0f6a-e7e2-4fae-b35d-b19edd588476) (recommended).

# Forward
When you're trying to set up a new website, the very first thing you need to do is figure out what you're going name the site and what domain you're going to buy. At the time of writing (15-10-2019), there are 1,527 [Top-level domains](https://en.wikipedia.org/wiki/Top-level_domain) (you can view the whole list on [iana.org](https://data.iana.org/TLD/tlds-alpha-by-domain.txt)). While a *very* large number of the "good" ones are already registered with `.com`, `.org`, etc., you can pick a TLD that most people might not have heard of and it's quite likely that you'll be able to find it. For example, I was trying to come up with a name for my podcast and I wanted a domain that would be easy to remember so they needed to go together. I looked around at what was available and came up with Redacted Life. As it so happens, `.life` is a TLD and `redacted` was unregistered; [redacted.life](https://redacted.life) was soon mine 😉

# What *is* a domain?
Essentially, a domain is the street address to a website. When you're using Google Maps or [OpenStreetMap](https://openstreetmap.org) (recommended), you enter the address of the place you want to go. In the background, the maps application is turning that address into geographic coordinates. When you're connecting to a website, your browser turns the domain into an IP address. For more information on that process and the related concerns, read sections one and two of a [previous post](/blog/dns-and-root-certificates-what-you-need-to-know/#1-what-is-dns-and-why-does-it-concern-you).

[ICANN](https://en.wikipedia.org/wiki/ICANN) (the Internet Corporation for Assigned Names and Numbers) is the non-profit organisation responsible for domains as well as some other things. ICANN lets domain registrars register domains on customers' behalf similar to the relationship between car dealerships and the manufacturer. Different registrars have different pricing schemes along with different plans and additional features but all of them pay a fee per-transaction according to what ICANN dictates. You can read more about that at [icann.org](https://icann.org). Some registrars will include the fee in your overall price but some will display it seperately at checkout and add it to your total. Many webhosts will bundle a domain with your package but I recommend purchasing it elsewhere as they tend to be more expensive even at the host's lower rate.

Another important thing to mention is that you're not actually *buying* the domains. You're really just renting it and will have to pay a yearly fee in most cases. I haven't seen a monthly plan yet but I'm sure they exist.

# Choosing one
Picking a domain name can be a huge decision. In many cases, it's a permanent decision. Once you register it, get your site(s) online, and start getting visitors, the only way you can really change it is to buy the new one but configure a redirect from the old to the new and continue paying for both. If you run federated serviced, there's simply no way around keeping the old one unless you start from scratch with 0 follows and followers for any of your users.

# Pricing
When registering a *new* domain, I often take a look at [tld-list.com](https://tld-list.com/) to see which registrars are cheaper for the first year and which are cheaper for the following years. Quite often, you'll see really low prices with a lighter gray price above it. The lower one is what you pay for the first year and the faded one is what you'll pay after that. TLD-list shows both of them so you know what you'll be paying right off the bat as well as what you'll be paying in the future. In general, however, there are a few registrars I tend to use regardless of price.

# Registrars
## [Gandi](https://gandi.net)
I use Gandi for my main websites, [nixnet.xyz](https://nixnet.xyz), for a few reasons. Originally, the big reason was managed email. I knew running my own email server would, one, be really difficult and time-consuming and, two, was precarious. If I didn't set everything up properly, I ran the risk of getting my domain put on a blacklist; once you're on a blacklist on one website, you're soon on all of them and it's *very* difficult to get back off.

Another reason is that they have some nice APIs available that I'm going to make use of for [Invidious](https://github.com/omarroth/invidious). The IP address of my server was recently blocked so [the instance](https://invidious.nixnet.xyz) completely stopped working. I'm going to write an Ansible playbook that will let me completely automate the process of buying a new VPS, migrating Invidious to it, and changing DNS records in Gandi in realtime as the IP addresses are blocked. It may be months, even a year, before I actually get around to making that happen but it will eventually.

**NOTE:** If you have a [SoloKey](https://solokeys.com/), [Yubikey](https://www.yubico.com/products/yubikey-hardware/), etc. I recommend enabling 2FA in Gandi with it and, even if you don't, you should still enable 2FA with [andOTP](https://github.com/andOTP/andOTP) or [FreeOTP](https://github.com/freeotp/freeotp-ios). With something as sensitive as domains, the extra level of security is essential.

## [Namesilo](https://namesilo.com)
The domains I have with Namesilo are for my podcast, [redacted.life](https://redacted.life), and my email server, [nixnet.email](https://nixnet.email). Namesilo *offers* some simple features like webhosting but I have no use for them. Namesilo just tends to be cheaper than the rest and, even though they have a *terrible* UI (imo), I barely have to interact with it and the price makes up for that detriment.

**EDIT:** Namesilo apparently has a new UI in the works. You can use it by going to [new.namesilo.com](https://new.namesilo.com/)
