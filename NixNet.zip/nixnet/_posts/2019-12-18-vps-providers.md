---
layout: post
title: VPS providers
subtitle: Some recommendations and considerations
description: Some recommendations and considerations to keep in mind when choosing a VPS provider
cover: /assets/posts/disk.png
tags: sysadmin hosting self self2019
date: 2019-12-18 21:35 -0500
---
# Forward
You should always be careful when choosing a VPS provider. In the online world,
*everyone* relies on someone somewhere in the chain. Even if you're
[self-hosting](https://en.wikipedia.org/wiki/Self-hosting_(web_services)) your
services on your own hardware in your living room, your ISP could suddenly
decide that you're using too much bandwidth and throttle your speeds or possibly
cut you off entirely. When you're using a VPS provider (as will be discussed
further down), someone in the datacentre could make a mistake and power down the
machine your VM is running on.

Choosing a dependable and trustworthy provider is of paramount importance when
deciding to run web services for yourself and especially for others.

# Considerations to keep in mind
## Key disclosure
This is one of the more important facets of choosing a provider. [Key disclosure
laws](https://en.wikipedia.org/wiki/Key_disclosure_law) can be used to force
server administrators[^1] to give their encryption keys to law enforcement. If
you use full disk encryption, you might have to give up the passphrase used to
decrypt the server. If files are encrypted on-disk, these might be subject to
surrender as well. It depends on the country and their implementation of the
law. These are the nations that have some form of legislation pertaining to key
disclosure:

1. Antigua and Barbuda
2. Australia
3. Canada
4. France
5. India
6. Ireland
7. Norway
8. Russia
9. South Africa
10. United Kingdom
11. Belgium[^2]
12. Estonia
13. Finland[^2]
14. New Zealand (unclear)
15. The Netherlands[^2]
16. United States (see the [Wikipedia
    article](https://en.wikipedia.org/wiki/Key_disclosure_law#United_States) as
    this is an unusual situation)

These nations *don't* have key disclosure legislation and can be considered safe
to use in this respect.
1. Czech Republic
2. Germany
3. Iceland
4. Italy
5. Poland
6. Sweden (it has been proposed, however)
7. Switzerland

## Local laws
In addition to key disclosure, you're also *generally* subject to the laws of
that nation, whatever they may be. For example, Germany requires that an
[Impressum](https://en.wikipedia.org/wiki/Impressum) be displayed on any public
website. I have chosen to ignore that as they rarely enforce the law for
non-German citizens; this is just an example. A more serious one that *would* be
enforced is their [censorship
rules](https://en.wikipedia.org/wiki/Censorship_in_Germany) meaning that
anything with user-generated content must be moderated or provide plausible
deniability[^3].

## Speeds
Another factor to consider under location is distance from *you*. If you're
running a game server such as
[Minetest](https://wiki.minetest.net/Setting_up_a_server), you'll want it to be
as geographically close to you as possible to reduce latency. That said, my
Minecraft server (yes, Mine*craft* 😞) is in Germany while I'm in the US.
Neither me nor any of my friends have actually *noticed* high latency so it's
not such a huge deal, just something to keep in mind if speed is of great
import.

## KVM vs OpenVZ
Make sure your provider offers full KVM virtualisation, not OpenVZ. VPS
providers that use OpenVZ tend to grossly oversell[^4] their platform and you
may run into performance issues if they don't plan properly. Overselling is
still possible with KVM but providers tend to do it much less.

You would also be unable to have full disk encryption, custom operating systems,
custom kernels, etc. You wouldn't be able to do anything at a particularly low
level like install WireGuard DKMS modules or even choose an OS they don't
already provide. For example, if you want [Alpine
Linux](https://alpinelinux.org/) for how lightweight it is or
[RancherOS](https://rancher.com/rancher-os/) for its container optimisation, you
wouldn't be able to use them unless your provider has already set up and
configured OpenVZ images for them.

# Providers
I have personal experience with [Digital Ocean](https://www.digitalocean.com/),
[netcup](https://netcup.eu), and [BuyVM](https://buyvm.net/). In my opinion, DO
is terribly overpriced if you're not wanting to scale like a huge enterprise and
make use of their Teams features, the API for spinning up high-compute droplets
on-demand for a short period of time, things like that. I would *only* recommend
DO for larger businesses. netcup, BuyVM, and Hetzner are much better options.

## netcup
The majority of my services run on servers from [netcup](https://netcup.eu) and
I highly recommend them. They're based in Germany and thus not subject to key
disclosure laws. Depending on where in the world you are, they may or may not
require legal identification such as your passport or driver's license; I'm in
the US and wasn't required to do any of that. Payment is done through PayPal but
does not require a PayPal account. They offer full KVM virtualisation so you're
not limited to images they provide.

Head to my [Affiliates](/affiliates) page for discounts on their various
offerings.

## BuyVM
My [DNS](/dns) and [Tor exits](/tor-nodes) are on [BuyVM](https://buyvm.net)
"slices". I'm using Slice 1024 for them but may consider upgrading if there's
enough interest. BuyVM has an interesting story; they started out as an "arm" of
[Frantech](https://frantech.ca) but are now the sole service provided by them.
Frantech was originally a more user-friendly service similar to Digital Ocean
that sort of held your hand through the setup and BuyVM was the "do it yourself"
version. They provided servers and expected you to know what to do with them.
BuyVM was *way* more popular than Frantech; the latter actually ended up losing
money. They eventually shut Frantech down and just run BuyVM under the name.

They are *very* Tor-friendly and pretty much forward all DMCA reports to
/dev/null. After paying for my servers, I opened a support ticket letting them
know that they would be Tor exits. I got a response saying something along the
lines of "cool! 👍" and that's it. I set Tor up, configured the system to
auto-update and reboot as needed, and they've run themselves since. I've never
gotten an abuse report of any kind or an email about them even though they've
been online for over five months.

I have nothing but good to say about BuyVM but I wouldn't use them when you need
something with more power.

## Hetzner
I haven't personally used [Hetzner](https://www.hetzner.com/) yet but I plan to
eventually. I find that netcup and Hetzner have complementing plans; if Hetzner
has something with specs below what you would like but the next one up is too
expensive, netcup like has something in the middle. The reverse is also true;
Hetzner fills gaps that netcup might have. In addition, they have dedicated
server plans. This gives you remote access to baremetal machines so you get
*much* more performance, you can run your own VMs, etc.

Hetzner also has auctions quite often. This gives you the opportunity to rent
physical hardware at a lower price, rather than paying for a virtual machine or
for one of their dedicated plans. You can also ship them a server you *own* and
pay for space on a rack in their datacentre (this is colocating). It can be very
expensive though; their cheapest option starts at 119.00€/mo.

[^1]: It can really be used to compell *anyone* to surrender their keys
[^2]: Those who know how to access a given system may be compelled to share
    their knowledge. This, however, does not apply to the suspect or to their
    family members
[^3]: This is where the user-generated content is hidden from the owner in such
    a way that it can't be easily removed.
    [PrivateBin](https://privatebin.info/) is one such service that provides
    plausible deniability; everything is encrypted and decrypted client-side so
    the server (and, by extension, the admin) can't see any of the public data
    *to* remove it
[^4]: "Overselling" is when a provider takes advantage of "ballooning" with KVM
    or "bursting" with OpenVZ. These features allow VMs or containers to borrow
    resources from others; when a provider oversells a machine, they are banking
    on their clients not using all of the resources they're paying for
[^5]: "Colocate" means that their hardware is in the same datacentre as someone
    else's. Providers that colocate often share the cost of the building,
    utilities, internet service, etc. though netcup and Hetzner have their own
    networks.
