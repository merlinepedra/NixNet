---
layout: post
title: Resizing LUKS-encrypted LVM partitions
subtitle: Increasing the size of LVM partitions encrypted with LUKS
description: Mostly copy/paste tutorial on increasing the size of LVM partitions that have been encrypted with LUKS
tags: sysadmin cli encryption
cover: /assets/posts/disk.png
date: 2019-08-21 20:09 -0400
---
My server has been sporadically down for the past couple of weeks as I attempted to take advantage of my increased storage. The server has 160 GB but I was only able to use 40 of those because the partitions were too small. I just figured it out and thought I'd write about it 😉

# Forward
There are ways you can do this entirely in CLI but I found a GUI easier. I don't say that often but it holds true in this case. Partitioning always scares me because of the *huge* potential for data loss. Using [GParted](https://gparted.org/) as I do here was risky because graphical tools can fail as well but I had already tried with `fdisk` and `parted` and I must have done something wrong because it didn't work. This method will work for both servers as well as desktops/laptops. The only requirement for servers is that you know the encryption key and the only requirement for PCs is a flash drive or something you can boot from. For images, I used GParted's [live image](https://gparted.org/livecd.php). Before partitioning, I *always* recommend taking backups or snapshots so, even if something goes wrong, you're not permanently screwed and you can revert back to the previous setup.

# Resizing partitions
The process here is rather simple. Just open GParted (it should open right on boot) and drag the right side of the **logical** partition to fill all unallocated space. After, increase the size of the `[Encrypted]` partition to take up the remaining space in the logical volume.

# Resizing everything else
First thing is to open the encrypted volume so you can make changes to it. Do that with:
```
cryptsetup luksOpen /dev/sdX5 cryptdisk
```
Of course, replace sdX5 with your encrypted partition. You can also use whatever name you want in place of `cryptdisk`; that's just what I like. Next, you're going to resize the physical volume with:
```
pvresize /dev/mapper/cryptdisk
```

Run `pvdisplay -m` and take a look at the output. Somewhere, you should see something like this:
```
Logical volume      /dev/xXxXxXxX/root
```

`xXxXxXxX` will be your logical volume group. `root` might not be what you want to extend though; there could be something that says `home` as well. If that's the case, you probably want to increase the size of that instead. My server shows `swap_1` and `root` and I certainly don't need 124 GB of swap. Take note of which path you'll be using for the next command. You're going to resize the logical volume to fill the remaining space.
```
lvextend +100%FREE /dev/xXxXxXxX/root
```

The last step is checking the encrypted volume itself if needed then extending it. If `resize2fs` prompts you to run `e2fsck` then do it and I recommend optimising everything it asks about.
```
resize2fs -p /dev/xXxXxXxX/root
```

After that, simply reboot and run `df -h` to see if it worked!
