---
layout: post
title: "Nitter put behind HTTP Basic Auth"
subtitle: "Sorry for the inconvenience but I'm tired"
description: Nitter has been put behind an HTTP BasicAuth dialogue to mitigate abuse of automated DMCA tools
date: 2021-12-30 13:10 -0500
---

[dmca.pro](https://dmca.pro) has been issuing DMCA notices against Twitter
content accessed through [our Nitter instance](https://nitter.nixnet.services)
every week for almost six months. I spent a few months ignoring them but they
started CCing our server provider, [Hetzner](https://hetzner.com).

For the last few months, Hetzner has been forwarding these notices to me and
creating abuse tickets for every single one of them. They've started threatening
to disable the IP address for NixNet's primary server; this would effectively
take all of NixNet down. I've responded to every single one of these abuse
tickets, but in the last few, I also asked to speak with a real person from
Hetzner to discuss the situation. I have received no response.

I've been dealing with this crap for months and I'm tired of it. I put Nitter
behind an [HTTP Basic
Auth](https://en.wikipedia.org/wiki/Basic_access_authentication) dialogue so the
automated tools these individuals from dmca.pro are using won't be helpful.

- Username: `nitter`
- Password: `nitter`

Most RSS readers will allow you to enter credentials when adding a feed. If not,
try using this URL with embedded credentials and see if it works.

- `https://nitter:nitter@nitter.nixnet.services`

I apologise for the inconvenience but I'm tired of being inundated with
senseless DMCA notices and of being threatened by our server provider.
