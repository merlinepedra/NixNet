---
layout: post
title: On "Free Speech"
---
I'm seeing a lot of drama lately about "Free Speech" and I want to make my views on it known. It is not my intention to be inflamatory or to insult anyone, neither is this aimed at a specific person. I am deeply bothered by the content I see every day and I need to write my thoughts down.

---

First of all the term "Free Speech" is defined as
> the right of people to express their opinions publicly without governmental interference, subject to the laws against libel, incitement to violence or rebellion, etc."
