---
layout: page
title: Finance
description: Some financial information about NixNet
subtitle: Some financial information about NixNet
cover: /assets/pages/finance.png
---

If you would like to donate to NixNet to support our work, please use [fosspay](https://nixnet.services/donate/) (preferred) or [Liberapay](https://liberapay.com/Amolith/). I also have some [affiliate links](/affiliates) for a few companies and services we use.

---

See the [about page](/about) for information regarding specific servers.

### Monthly server cost
* **Main**: 54,00€ ($63.52)
* **BBB:** 34.90€ ($41.05)
* **BBB TURN:** 4,90€ ($5.76)
* **Email:** 9,25€ ($10.80)
* **DNS-LV:** $3.50
* **DNS-NY:** $3.50
* **DNS-LU:** $3.50

**Total:** $131.63/mo

### Yearly domain cost
* **pwned.life:** $23.99
* **nixnet.social:** $23.99
* **nixnet.services:** $23.99
* **nixnet.email:** $15.99
* **paranoid.network:** $15.99
* **linux.monster:** $9.99
* **nixnetmail.com:** $8.99
* **3733366.xyz:** $1.16
* **7748229.xyz:** $1.16
* **647630.xyz:** $1.16

**Total:** $126.41/yr

---

### Overall total: $142.16/mo
